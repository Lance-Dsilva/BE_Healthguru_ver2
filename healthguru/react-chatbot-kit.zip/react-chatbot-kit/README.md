[![pipeline status](https://gitlab.com/FredrikOseberg/react-chatbot-kit/badges/master/pipeline.svg)](https://gitlab.com/FredrikOseberg/react-chatbot-kit/-/commits/master)

# Introduction

react-chatbot-kit provides an easy way to get started building chatbots.

![package preview](https://media.giphy.com/media/J5kWtT2niLglbF7F54/giphy.gif)

## Documentation

View the documentation here: https://fredrikoseberg.github.io/react-chatbot-kit-docs/
